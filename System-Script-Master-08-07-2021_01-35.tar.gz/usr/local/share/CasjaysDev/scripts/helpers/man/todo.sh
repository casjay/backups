#!/usr/bin/env bash
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
APPNAME_README="todo.sh"
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
##@Version       : 202108050003-git
# @Author        : casjay
# @Contact       : casjay
# @License       : WTFPL
# @ReadME        : todo.sh --help
# @Copyright     : Copyright: (c) 2021 casjay, casjay
# @Created       : Thursday, Aug 05, 2021 00:03 EDT
# @File          : todo.sh
# @Description   : Manual for todo.sh
# @TODO          : 
# @Other         : 
# @Resource      : 
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Set variables
__heading="- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Set functions
__sed_head() { sed 's#..* :##g;s#^ ##g'; }
__grep_head() { grep -sE '[".#]?@[A-Z]' "$(type -P "${2:-$todo.sh}")" | grep "${1:-}"; }
__version() { __grep_head 'Version' "$(type -P "todo.sh")" | __sed_head | head -n1 | grep '^'; }
__printf_color() { printf "%b" "$(tput setaf "$2" 2>/dev/null)" "$1" "$(tput sgr0 2>/dev/null)"; }
__printf_head() { __printf_color "\n\t\t$__heading\n\t\t$2\n\t\t$__heading\n" "$1"; }
__printf_help() {
  test -n "$1" && test -z "${1//[0-9]/}" && local color="$1" && shift 1 || local color="4"
  local msg="$*"
  shift
  __printf_color "\t\t$msg\n" "$color"
}
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Begin help
__printf_head "5" "todo.sh: A todo manager"
printf '\n'

__printf_help "5" "Usage: todo.sh  "
__printf_help "4" "BeginHelp"
__printf_help "4" " -  "
__printf_help "4" "-c, --config            - generate user config file"
__printf_help "4" "-v, --version           - show script version"
__printf_help "4" "-h, --help              - Shows this message"
__printf_help "4" "--options               - files used for completion"

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# end help
printf '\n'
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# End application
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# lets exit with code
exit "${exitCode:-0}"

