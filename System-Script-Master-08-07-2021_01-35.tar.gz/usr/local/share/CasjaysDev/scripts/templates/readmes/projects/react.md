# 👋 Welcome to the ProjectName project 👋

  ProjectDescription

## Run production  

```shell
npm i
npm run build
```

## Run Development  

```shell
npm i -D
npm run start
```
  
## Author  

👤 **AuthorName**  
