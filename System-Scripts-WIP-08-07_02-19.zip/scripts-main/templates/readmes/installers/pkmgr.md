## GEN_README_REPLACE_APPNAME
  
### GEN_README_REPLACE_DESCRIBE  
  
#### Requires scripts to be installed

```shell
sudo bash -c "$(curl -LSs <https://github.com/pkmgr/installer/raw/GEN_README_REPLACE_DEFAULT_BRANCH/install.sh>)" && sudo pkmgr install installer  

### Automatic install/update:  

```shell
bash -c "$(curl -LSs https://github.com/pkmgr/installer/raw/GEN_README_REPLACE_DEFAULT_BRANCH/install.sh)"
pkmgr curl GEN_README_REPLACE_URL/GEN_README_REPLACE_APPNAME.sh
```
