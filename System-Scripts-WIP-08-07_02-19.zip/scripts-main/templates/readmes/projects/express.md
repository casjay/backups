# 👋 Welcome to the ProjectName project 👋

  ProjectDescription

## Run production  

```shell
npm i
node run start
```

## Run Development  

```shell
npm i -D
npm run dev
```
  
## Author  

👤 **AuthorName**  
