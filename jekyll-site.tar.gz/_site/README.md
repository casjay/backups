### My Jekyll Theme  
  
[![Gem Version](https://badge.fury.io/rb/jekyll-casjaysdev.svg)](https://badge.fury.io/rb/jekyll-casjaysdev) [![Build Status](https://travis-ci.org/casjay-templates/jekyll-site.svg?branch=master)](https://travis-ci.org/casjay-templates/jekyll-site)
  
jekyll-casjaysdev theme for my sites
  
Uses the jekyll-casjaysdev theme - [jekyll-casjaysdev](https://github.com/casjay-themes/jekyll-casjaysdev)
